General notes

Designs assume you are using "2x4" construction.  We found that no matter how carefully you select the boards - 2x4 (especially) and 2x6 lumber is always a little warped, twisted, cupped, and wavy.  The dimensions allow for a light pass through the jointer and planer to square and true the boards.  If you don't have those tools, it is possible (though difficult) to sand boards square, true and smooth.    

We assume that if you're starting with rough hewn hardwoods you can make adjustments depending on the choices you make between 4/4 and 8/4 lumber.  BTW - considering the labor you'll be putting into your project, we recommend that you seriously consider spending the extra money for good wood.

In either case, carefully review the plans before you cut anything.  There are a number of places where a 1/16" difference is huge.  Also, buy your hardware first and review the placement of pilot holes, etc.  The dimensions on the drawings fit the hardward we could buy at our local hardware stores.  You may need to make some adjustments.


VH_1of6_SideR

	1.  The Left side is a mirror image of the Right, except there are holes for the hinges in the Left side.  The left side information (holes and their dimensions) are in separate layers in the drawings.  You can turn on/off the Dimleft/Leftonly and Dim1 layers to make it easier to read the drawings.


VH_2of6_Framework

	1.  The Stiffners serve 3 purposes.  First, they stiffen the sides.  Second, they store the leg and arm rests when they aren't in use.  Third, they provide attachment points for the eyebolts used to tie ankles and wrists when the sub is placed laterally over the horse or with the pillory attachment.  

	When affixing the stiffners, they should be glued and screwed roughly parallel to and inset 1/4" from the inside edges of the cutout area and 2-1/2" above the bottom edge.  And a VERY IMPORTANT point regarding storage of the arm and leg rests.  To ensure that the VersaHorse will fold up with the padded parts stowed away, the Stiffners should be affixed so that the end with the two 7/16" holes are oriented toward the top of the right side and the bottom of the left side.